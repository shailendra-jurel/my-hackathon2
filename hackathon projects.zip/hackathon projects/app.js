const inputtext = document.querySelectorAll(".text-area");
const comment = document.querySelectorAll(".right-usercomment");
const post =    document.querySelectorAll("post-button");
const replycomment =  document.querySelectorAll("reply-comment");






    post.addEventListener("click", () => {

            comment.innerText = inputtext;
        
    });

    replycomment.addEventListener("click" ()=>{

        var textfield = document.createElement("input");







    })


    

